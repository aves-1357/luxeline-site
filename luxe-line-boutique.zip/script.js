// Smooth scroll for navigation links
document.querySelectorAll('nav a').forEach(link => {
  link.addEventListener('click', function (e) {
    e.preventDefault();
    const section = document.querySelector(this.getAttribute('href'));
    section.scrollIntoView({ behavior: 'smooth' });
  });
});

// Placeholder interaction for product cards
document.querySelectorAll('.product').forEach(product => {
  product.addEventListener('click', () => {
    alert('This is a sample product. Full shop functionality coming soon!');
  });
});
